# Validation report

- Native manifest and exactly 2 focused skills
- Upstream data validator: PASS
- Upstream tests: 36/36 PASS
- Inspiration catalogue validator: PASS
- Inspiration tests: 4/4 PASS
- Search and selector smoke tests: PASS
- Python/JSON syntax: PASS
- No `.env`, `.pyc`, `__pycache__`, or `.coverage`
- Windows installer includes automatic backup, doctor, failure rollback, and manual restore
- v1.0.1 resolves the PowerShell `Py` helper / Windows `py.exe` command-name collision by using a uniquely named helper and the launcher's absolute executable path

No Startaply application source file is modified by this package.
