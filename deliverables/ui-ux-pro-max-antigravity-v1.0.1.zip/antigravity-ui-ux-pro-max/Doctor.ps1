﻿[CmdletBinding()]
param([string]$PluginPath=(Join-Path $env:USERPROFILE ".gemini\config\plugins\ui-ux-pro-max"))
$ErrorActionPreference="Continue"; $script:P=0; $script:W=0; $script:F=0
function Pass($m){$script:P++;Write-Host "[PASS] $m" -ForegroundColor Green}
function Warn($m){$script:W++;Write-Host "[WARN] $m" -ForegroundColor Yellow}
function Fail($m){$script:F++;Write-Host "[FAIL] $m" -ForegroundColor Red}
Write-Host "UI/UX Pro Max Antigravity Doctor`nPlugin: $PluginPath`n" -ForegroundColor Cyan
if(-not(Test-Path $PluginPath)){Fail "Plugin directory missing";exit 1}else{Pass "Plugin directory exists"}
try{$m=Get-Content(Join-Path $PluginPath "plugin.json")-Raw|ConvertFrom-Json;if($m.name -eq "ui-ux-pro-max"){Pass "Native manifest parses"}else{Fail "Wrong manifest name"};$extra=@($m.PSObject.Properties.Name|Where-Object{$_ -notin @('$schema','name','description')});if($extra.Count){Warn "Non-standard manifest fields: $($extra -join ', ')"}else{Pass "Manifest contains only native fields"}}catch{Fail "Manifest parse failed: $($_.Exception.Message)"}
$skills=@(Get-ChildItem(Join-Path $PluginPath "skills")-Directory -ErrorAction SilentlyContinue)
if((@($skills.Name|Sort-Object)-join '|') -eq "design-inspiration-research|ui-ux-pro-max"){Pass "Exactly 2 focused skills installed"}else{Fail "Unexpected skills: $($skills.Name -join ', ')"}
foreach($s in $skills){$f=Join-Path $s.FullName "SKILL.md";$c=if(Test-Path $f){Get-Content $f -Raw}else{""};if($c -match '(?s)^---.*?name:\s*[^\r\n]+.*?description:\s*[^\r\n]+.*?---'){Pass "$($s.Name) frontmatter valid"}else{Fail "$($s.Name) frontmatter invalid"}}
$bad=@(Get-ChildItem $PluginPath -Recurse -Force|Where-Object{$_.Name -in @('.env','.coverage','__pycache__') -or $_.Extension -eq '.pyc'})
if($bad.Count){Fail "Forbidden files: $($bad.FullName -join ', ')"}else{Pass "No secret/cache/coverage artifacts"}
$dupes=@((Join-Path $env:USERPROFILE ".gemini\config\skills\ui-ux-pro-max"),(Join-Path $env:USERPROFILE ".gemini\antigravity\skills\ui-ux-pro-max"),(Join-Path $env:USERPROFILE ".agents\skills\ui-ux-pro-max")|Where-Object{Test-Path $_})
if($dupes.Count){Warn "Duplicate skill copies: $($dupes -join ', ')"}else{Pass "No common duplicate global copy"}
$Python=$null;$Prefix=@();$candidates=@(@{c='py';p=@('-3')},@{c='python';p=@()},@{c='python3';p=@()})
foreach($x in $candidates){$found=Get-Command $x.c -CommandType Application -ErrorAction SilentlyContinue|Select-Object -First 1;if($found){$cmd=$found.Source;$pre=[string[]]$x.p;$v=& $cmd @pre --version 2>&1;if($LASTEXITCODE -eq 0 -and "$v" -match 'Python 3\.'){ $Python=$cmd;$Prefix=$pre;Pass "Python available: $($x.c) $($pre -join ' ') ($v)";break }}}
if(-not $Python){Fail "Python 3 not found"}else{
 $env:PYTHONDONTWRITEBYTECODE="1"
 function RunPythonCheck($label,[string[]]$Arguments){$all=@();$all+=$Prefix;$all+=$Arguments;$o=& $Python @all 2>&1;if($LASTEXITCODE -eq 0){Pass $label}else{Fail "$label — $($o -join ' ')"}}
 $core=Join-Path $PluginPath "skills\ui-ux-pro-max";$research=Join-Path $PluginPath "skills\design-inspiration-research"
 RunPythonCheck "Design data validates" @((Join-Path $core "scripts\validate_data.py"))
 RunPythonCheck "Inspiration catalogue validates" @((Join-Path $research "scripts\validate_sources.py"))
 RunPythonCheck "Design search works" @((Join-Path $core "scripts\search.py"),"accessible mobile job portal","--domain","ux","--max-results","1","--json")
 RunPythonCheck "Source selector works" @((Join-Path $research "scripts\select_sources.py"),"mobile job product UI","--max-results","3","--format","json")
 RunPythonCheck "Inspiration tests pass" @("-m","unittest","discover","-s",(Join-Path $research "scripts\tests"),"-p","test_*.py")
}
Write-Host "`nSummary: $script:P passed, $script:W warnings, $script:F failed"
if($script:F){exit 1}else{exit 0}
