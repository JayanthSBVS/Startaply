#!/usr/bin/env python3
"""Transactional installer for the lean UI/UX Pro Max Antigravity plugin."""
from __future__ import annotations

import argparse
import json
import shutil
import sys
from datetime import datetime
from pathlib import Path
from typing import Sequence

import doctor

PLUGIN_NAME = "ui-ux-pro-max"
REQUIRED_FILES = [
    "plugin.json",
    "skills/ui-ux-pro-max/SKILL.md",
    "skills/ui-ux-pro-max/scripts/search.py",
    "skills/ui-ux-pro-max/scripts/validate_data.py",
    "skills/design-inspiration-research/SKILL.md",
    "skills/design-inspiration-research/resources/sources.json",
    "skills/design-inspiration-research/scripts/validate_sources.py",
]
FORBIDDEN_NAMES = {".env", ".coverage", "__pycache__"}


def default_target_root() -> Path:
    return Path.home() / ".gemini" / "config" / "plugins"


def default_backup_root() -> Path:
    return Path.home() / ".gemini" / "config" / "plugin-backups" / PLUGIN_NAME


def validate_source(source: Path) -> None:
    missing = [relative for relative in REQUIRED_FILES if not (source / relative).is_file()]
    if missing:
        raise RuntimeError(f"Incomplete package; missing: {', '.join(missing)}")
    manifest = json.loads((source / "plugin.json").read_text(encoding="utf-8-sig"))
    if manifest.get("name") != PLUGIN_NAME:
        raise RuntimeError(f"Unexpected plugin name: {manifest.get('name')!r}")
    forbidden = [
        str(item)
        for item in source.rglob("*")
        if item.name in FORBIDDEN_NAMES or item.suffix.lower() == ".pyc"
    ]
    if forbidden:
        raise RuntimeError(f"Package contains forbidden files: {', '.join(forbidden)}")


def unique_backup_path(backup_root: Path) -> Path:
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    return backup_root / stamp


def install(
    package_root: Path,
    target_root: Path,
    backup_root: Path,
    *,
    skip_doctor: bool = False,
) -> Path | None:
    source = package_root / "plugin"
    validate_source(source)
    target_root.mkdir(parents=True, exist_ok=True)
    target = target_root / PLUGIN_NAME
    backup_path: Path | None = None
    previous_env = False
    replacement_started = False

    try:
        if target.exists():
            print("\n==> Backing up current plugin")
            backup_root.mkdir(parents=True, exist_ok=True)
            backup_path = unique_backup_path(backup_root)
            previous_env = any(item.name == ".env" for item in target.rglob("*"))
            shutil.copytree(target, backup_path)
            print(f"Backup: {backup_path}")

        print("\n==> Installing lean plugin")
        replacement_started = True
        if target.exists():
            shutil.rmtree(target)
        shutil.copytree(source, target)

        if not (target / "plugin.json").is_file():
            raise RuntimeError("Copy verification failed: target manifest missing")

        if previous_env:
            print("[WARN] Old plugin contained .env. Rotate any real key; it exists only in the backup.")

        if not skip_doctor:
            print("\n==> Running health checks")
            results = doctor.check_plugin(target)
            if results.failed:
                raise RuntimeError(f"Health checks failed ({results.failed} failed checks)")

        print("\nInstallation complete.")
        print("Restart Antigravity, start a NEW conversation, and confirm this plugin exposes exactly 2 skills.")
        if backup_path:
            print(f"Rollback backup: {backup_path}")
        return backup_path
    except Exception:
        if replacement_started and target.exists():
            shutil.rmtree(target, ignore_errors=True)
        if backup_path and backup_path.exists():
            shutil.copytree(backup_path, target)
            print("[ROLLBACK] Previous plugin restored.")
        raise


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--target-root", type=Path, default=default_target_root())
    parser.add_argument("--backup-root", type=Path, default=default_backup_root())
    parser.add_argument("--skip-doctor", action="store_true")
    args = parser.parse_args(argv)
    package_root = Path(__file__).resolve().parent
    try:
        install(package_root, args.target_root, args.backup_root, skip_doctor=args.skip_doctor)
        return 0
    except Exception as error:
        print(f"\nInstallation failed: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
