#!/usr/bin/env python3
"""Health checks for the lean UI/UX Pro Max Antigravity plugin."""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

PLUGIN_NAME = "ui-ux-pro-max"
EXPECTED_SKILLS = {"ui-ux-pro-max", "design-inspiration-research"}
ALLOWED_MANIFEST_KEYS = {"$schema", "name", "description"}
FRONTMATTER_RE = re.compile(
    r"\A---\s*\n(?=.*?^name:\s*\S.+$)(?=.*?^description:\s*\S.+$).*?^---\s*$",
    re.MULTILINE | re.DOTALL,
)
FORBIDDEN_NAMES = {".env", ".coverage", "__pycache__"}


@dataclass
class Results:
    passed: int = 0
    warnings: int = 0
    failed: int = 0

    def passed_check(self, message: str) -> None:
        self.passed += 1
        print(f"[PASS] {message}")

    def warn(self, message: str) -> None:
        self.warnings += 1
        print(f"[WARN] {message}")

    def fail(self, message: str) -> None:
        self.failed += 1
        print(f"[FAIL] {message}")


def default_plugin_path() -> Path:
    return Path.home() / ".gemini" / "config" / "plugins" / PLUGIN_NAME


def run_python_check(results: Results, label: str, arguments: Sequence[str]) -> None:
    env = os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONUTF8"] = "1"
    completed = subprocess.run(
        [sys.executable, *map(str, arguments)],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        encoding="utf-8",
        errors="replace",
        env=env,
        check=False,
    )
    if completed.returncode == 0:
        results.passed_check(label)
    else:
        output = completed.stdout.strip().replace("\n", " | ")
        results.fail(f"{label} — {output or 'command exited non-zero'}")


def check_plugin(plugin_path: Path, *, check_duplicates: bool = True) -> Results:
    plugin_path = plugin_path.resolve()
    results = Results()
    print("UI/UX Pro Max Antigravity Doctor")
    print(f"Plugin: {plugin_path}\n")

    if not plugin_path.is_dir():
        results.fail("Plugin directory does not exist")
        return results
    results.passed_check("Plugin directory exists")

    manifest_path = plugin_path / "plugin.json"
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
        results.passed_check("Native manifest parses")
        if manifest.get("name") != PLUGIN_NAME:
            results.fail(f"Manifest name is {manifest.get('name')!r}, expected {PLUGIN_NAME!r}")
        extras = sorted(set(manifest) - ALLOWED_MANIFEST_KEYS)
        if extras:
            results.warn(f"Non-standard manifest fields: {', '.join(extras)}")
        else:
            results.passed_check("Manifest contains only native fields")
    except Exception as error:
        results.fail(f"Manifest parse failed: {error}")

    skills_root = plugin_path / "skills"
    actual_skills = {item.name for item in skills_root.iterdir() if item.is_dir()} if skills_root.is_dir() else set()
    if actual_skills == EXPECTED_SKILLS:
        results.passed_check("Exactly 2 focused skills installed")
    else:
        results.fail(f"Unexpected skills: {', '.join(sorted(actual_skills)) or '(none)'}")

    for skill_name in sorted(actual_skills):
        skill_file = skills_root / skill_name / "SKILL.md"
        try:
            content = skill_file.read_text(encoding="utf-8-sig").replace("\r\n", "\n")
            if FRONTMATTER_RE.search(content):
                results.passed_check(f"{skill_name} frontmatter valid")
            else:
                results.fail(f"{skill_name} frontmatter invalid")
        except Exception as error:
            results.fail(f"{skill_name} SKILL.md unreadable: {error}")

    forbidden: list[str] = []
    for item in plugin_path.rglob("*"):
        if item.name in FORBIDDEN_NAMES or item.suffix.lower() == ".pyc":
            forbidden.append(str(item))
    if forbidden:
        results.fail(f"Forbidden secret/cache/coverage files: {', '.join(forbidden)}")
    else:
        results.passed_check("No secret/cache/coverage artifacts")

    if check_duplicates:
        home = Path.home()
        duplicate_candidates = [
            home / ".gemini" / "config" / "skills" / PLUGIN_NAME,
            home / ".gemini" / "antigravity" / "skills" / PLUGIN_NAME,
            home / ".agents" / "skills" / PLUGIN_NAME,
            home / ".agent" / "skills" / PLUGIN_NAME,
        ]
        duplicates = [str(path) for path in duplicate_candidates if path.exists()]
        if duplicates:
            results.warn(f"Duplicate global skill copies: {', '.join(duplicates)}")
        else:
            results.passed_check("No common duplicate global copy")

    results.passed_check(f"Python available: {sys.executable} ({sys.version.split()[0]})")
    core = skills_root / "ui-ux-pro-max"
    research = skills_root / "design-inspiration-research"
    run_python_check(results, "Design data validates", [core / "scripts" / "validate_data.py"])
    run_python_check(results, "Inspiration catalogue validates", [research / "scripts" / "validate_sources.py"])
    run_python_check(
        results,
        "Design search works",
        [core / "scripts" / "search.py", "accessible mobile job portal", "--domain", "ux", "--max-results", "1", "--json"],
    )
    run_python_check(
        results,
        "Source selector works",
        [research / "scripts" / "select_sources.py", "mobile job product UI", "--max-results", "3", "--format", "json"],
    )
    run_python_check(
        results,
        "Inspiration tests pass",
        ["-m", "unittest", "discover", "-s", research / "scripts" / "tests", "-p", "test_*.py"],
    )

    print(f"\nSummary: {results.passed} passed, {results.warnings} warnings, {results.failed} failed")
    return results


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plugin-path", type=Path, default=default_plugin_path())
    parser.add_argument("--no-duplicate-check", action="store_true")
    args = parser.parse_args(argv)
    results = check_plugin(args.plugin_path, check_duplicates=not args.no_duplicate_check)
    return 1 if results.failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
