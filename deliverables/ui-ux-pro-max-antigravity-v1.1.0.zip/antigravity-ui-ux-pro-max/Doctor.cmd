@echo off
setlocal
where py >nul 2>&1
if not errorlevel 1 goto use_py
where python >nul 2>&1
if not errorlevel 1 goto use_python
echo Python 3 was not found. Install Python 3 and try again.
set EXIT_CODE=1
goto finish
:use_py
py -3 "%~dp0doctor.py"
set EXIT_CODE=%ERRORLEVEL%
goto finish
:use_python
python "%~dp0doctor.py"
set EXIT_CODE=%ERRORLEVEL%
:finish
echo.
pause
exit /b %EXIT_CODE%
