#!/usr/bin/env python3
"""Restore a UI/UX Pro Max plugin backup."""
from __future__ import annotations

import argparse
import shutil
import sys
from datetime import datetime
from pathlib import Path
from typing import Sequence

PLUGIN_NAME = "ui-ux-pro-max"


def default_target_root() -> Path:
    return Path.home() / ".gemini" / "config" / "plugins"


def default_backup_root() -> Path:
    return Path.home() / ".gemini" / "config" / "plugin-backups" / PLUGIN_NAME


def choose_backup(backup_root: Path, explicit: Path | None) -> Path:
    if explicit:
        candidate = explicit
    else:
        candidates = sorted((path for path in backup_root.iterdir() if path.is_dir()), reverse=True) if backup_root.is_dir() else []
        if not candidates:
            raise RuntimeError(f"No backup found at {backup_root}")
        candidate = candidates[0]
    if not (candidate / "plugin.json").is_file():
        raise RuntimeError(f"Invalid backup (plugin.json missing): {candidate}")
    return candidate


def restore(target_root: Path, backup_root: Path, backup_path: Path | None = None) -> Path:
    selected = choose_backup(backup_root, backup_path)
    target_root.mkdir(parents=True, exist_ok=True)
    target = target_root / PLUGIN_NAME
    if target.exists():
        safety_root = backup_root.parent / f"{PLUGIN_NAME}-pre-restore"
        safety_root.mkdir(parents=True, exist_ok=True)
        safety = safety_root / datetime.now().strftime("%Y%m%d-%H%M%S-%f")
        shutil.copytree(target, safety)
        shutil.rmtree(target)
        print(f"Current plugin safety backup: {safety}")
    shutil.copytree(selected, target)
    print(f"Restored from: {selected}")
    print("Restart Antigravity and start a new conversation.")
    return selected


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--backup-path", type=Path)
    parser.add_argument("--target-root", type=Path, default=default_target_root())
    parser.add_argument("--backup-root", type=Path, default=default_backup_root())
    args = parser.parse_args(argv)
    try:
        restore(args.target_root, args.backup_root, args.backup_path)
        return 0
    except Exception as error:
        print(f"Restore failed: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
