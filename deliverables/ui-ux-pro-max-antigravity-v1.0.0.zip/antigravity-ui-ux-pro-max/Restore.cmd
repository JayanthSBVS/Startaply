@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Restore.ps1"
echo.
pause
