﻿[CmdletBinding()]
param([string]$BackupPath,[string]$TargetRoot=(Join-Path $env:USERPROFILE ".gemini\config\plugins"))
$ErrorActionPreference="Stop";$BackupRoot=Join-Path $env:USERPROFILE ".gemini\config\plugin-backups\ui-ux-pro-max";$Target=Join-Path $TargetRoot "ui-ux-pro-max"
if(-not $BackupPath){$latest=Get-ChildItem $BackupRoot -Directory -ErrorAction SilentlyContinue|Sort-Object Name -Descending|Select-Object -First 1;if(-not $latest){throw "No backup found at $BackupRoot"};$BackupPath=$latest.FullName}
if(-not(Test-Path(Join-Path $BackupPath "plugin.json"))){throw "Invalid backup: $BackupPath"}
if(Test-Path $Target){$safe=Join-Path $env:USERPROFILE ".gemini\config\plugin-backups\ui-ux-pro-max-pre-restore";New-Item -ItemType Directory $safe -Force|Out-Null;Copy-Item -LiteralPath $Target -Destination (Join-Path $safe (Get-Date -Format "yyyyMMdd-HHmmss")) -Recurse -Force;Remove-Item $Target -Recurse -Force}
Copy-Item $BackupPath $Target -Recurse -Force
Write-Host "Restored from $BackupPath" -ForegroundColor Green
Write-Host "Restart Antigravity and start a new conversation."
