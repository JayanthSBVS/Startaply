# UI/UX Pro Max — Lean Antigravity Edition

Native Windows package for standalone Antigravity 2.0. It replaces the unofficial 30-skill v4.1 pipeline with two focused skills: safe UI delivery and optional real-site inspiration research.

## Requirements

- Windows 10/11 and standalone Antigravity 2.0
- Python 3 (`py -3`, `python`, or `python3`)
- Chrome DevTools plugin recommended for visual research/verification

No Claude, API key, MCP server, paid service, or external Python package is required.

## Install

1. Close Antigravity.
2. Extract the complete ZIP.
3. Double-click `Install.cmd`.
4. Review the doctor output.
5. Reopen Antigravity, start a **new conversation**, and confirm `ui-ux-pro-max` is enabled with exactly two skills.

The old plugin is backed up to `%USERPROFILE%\.gemini\config\plugin-backups\ui-ux-pro-max\<timestamp>` before replacement. `Restore.cmd` restores the newest backup.

If Windows blocks the command file:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Install.ps1
```

## Security

The old export contained `skills\ui-ux-pro-max\scripts\.env`. This package does not include it. If it contained a real key, rotate that key and later remove it from the local rollback backup. Never share the value.

## Tests

Audit only:

```text
Use ui-ux-pro-max in AUDIT mode. Review this interface without modifying code. Give evidence and an ordered fix plan.
```

Existing project:

```text
Use ui-ux-pro-max in FAST mode. Preserve framework, routes, APIs and content. Run baseline checks, make the smallest change, then verify it.
```

Inspiration:

```text
Use design-inspiration-research for a trustworthy mobile-first career platform. Select three real public references, record actual evidence, and create an original direction. Do not write code or copy assets/layouts.
```

For web work, disable unrelated global plugins such as `science`, `android-cli-plugin`, and `test-skill-runner` to reduce context usage. Keep Chrome DevTools and modern web guidance enabled when useful.

## Attribution

Core UI/UX data and search scripts derive from `nextlevelbuilder/ui-ux-pro-max-skill` v2.12.0 under MIT. See `plugin/NOTICE.md` and `plugin/UPSTREAM-LICENSE.txt`.
