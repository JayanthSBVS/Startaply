---
name: design-inspiration-research
description: Researches public websites and design libraries when the user asks for visual inspiration, references, competitor UI patterns, Awwwards or Godly examples, or a fresh design direction. Selects a small relevant source set, uses Browser or Chrome DevTools for evidence, records real URLs, and synthesizes original patterns without cloning code, assets, branding, or layouts.
---

# Design Inspiration Research

Use only for explicit inspiration/reference research or a major redesign—not routine fixes.

## Rules

- Browse real resolvable URLs; never fabricate placeholder paths.
- Use at most five sources, normally three, from diverse source types.
- Do not log in, bypass access controls/anti-bot systems, or scrape private/prohibited content.
- Do not copy source code, text, logos, media, trademarks, or exact layouts.
- Never claim to inspect a page that Browser/Chrome DevTools could not open.

## Select candidates locally

```powershell
$ResearchRoot = Join-Path $env:USERPROFILE ".gemini\config\plugins\ui-ux-pro-max\skills\design-inspiration-research"
py -3 (Join-Path $ResearchRoot "scripts\select_sources.py") "<product page audience style>" --max-results 5 --format markdown
```

Use `python`/`python3` if needed. Validate catalogue edits with `scripts\validate_sources.py`.

## Workflow

1. Frame the product, page/flow, audience, primary task, qualities, device, and performance constraints.
2. Select 3–5 sources: preferably a pattern gallery, a product-flow library, and a relevant implementation/reference source.
3. Open each with Antigravity Browser or Chrome DevTools. Replace inaccessible sources instead of retrying repeatedly.
4. Record real URL/date, what was actually visible, hierarchy, section ordering, typography roles, color roles, component/interaction pattern, motion purpose/cost, one principle to adapt, and one pattern to avoid.
5. Create a short evidence matrix, then synthesize three original principles, page structure, token direction, interaction/motion direction, mobile adaptation, and explicit anti-copy constraints.
6. Save reusable findings to `design-system/<project>/INSPIRATION.md`; do not revisit all sites unless requirements changed.

```markdown
| Source | Observed pattern | Why it works | Adapt as | Do not copy |
|---|---|---|---|---|
| Real URL | Evidence | User/business reason | Original principle | Brand/assets/exact layout |
```

Research ends with recommendations, not a scraped dataset. Hand the brief to `ui-ux-pro-max` for safe implementation and verification.
