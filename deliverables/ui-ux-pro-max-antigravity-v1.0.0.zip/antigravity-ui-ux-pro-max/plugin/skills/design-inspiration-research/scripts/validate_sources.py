#!/usr/bin/env python3
"""Validate inspiration source catalogue."""
import json,re,sys
from pathlib import Path
from urllib.parse import urlparse
CATALOG=Path(__file__).resolve().parent.parent/"resources"/"sources.json"
ID=re.compile(r"^[a-z0-9][a-z0-9-]*$")
BAD=re.compile(r"[\[\]{}]|localhost|(?:^|[/.])example(?:[/.]|$)",re.I)

def validate(path=CATALOG):
    try: data=json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception as e: return [f"cannot read catalogue: {e}"]
    errors=[]; sources=data.get("sources") if isinstance(data,dict) else None
    if data.get("schemaVersion")!=1: errors.append("schemaVersion must be 1")
    if not isinstance(sources,list) or not sources: return errors+["sources must be a non-empty array"]
    ids=set(); urls=set()
    for i,s in enumerate(sources):
        label=f"sources[{i}]"
        if not isinstance(s,dict): errors.append(f"{label} must be an object"); continue
        for key in ("id","name","url"):
            if not isinstance(s.get(key),str) or not s[key].strip(): errors.append(f"{label}.{key} must be a non-empty string")
        sid=s.get("id",""); url=s.get("url","")
        if sid and not ID.fullmatch(sid): errors.append(f"{label}.id is invalid")
        if sid in ids: errors.append(f"duplicate id: {sid}")
        ids.add(sid)
        parsed=urlparse(url)
        if parsed.scheme!="https" or not parsed.netloc: errors.append(f"{label}.url must be absolute HTTPS")
        if BAD.search(url): errors.append(f"{label}.url contains a placeholder/local address")
        norm=url.rstrip("/").lower()
        if norm in urls: errors.append(f"duplicate URL: {url}")
        urls.add(norm)
        for key in ("categories","strengths","cautions"):
            value=s.get(key)
            if not isinstance(value,list) or not value or not all(isinstance(x,str) and x.strip() for x in value): errors.append(f"{label}.{key} must contain strings")
    return errors

def main():
    errors=validate()
    if errors:
        for error in errors: print("ERROR:",error)
        return 1
    print(f"OK: validated {len(json.loads(CATALOG.read_text(encoding='utf-8'))['sources'])} inspiration sources"); return 0
if __name__=="__main__": raise SystemExit(main())
