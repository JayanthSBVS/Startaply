#!/usr/bin/env python3
"""Select relevant sources from the local catalogue; no network requests."""
from __future__ import annotations
import argparse, json, re, sys
from pathlib import Path
from urllib.parse import urlparse

CATALOG = Path(__file__).resolve().parent.parent / "resources" / "sources.json"
TOKENS = re.compile(r"[a-z0-9]+")
EXPAND = {
 "job":{"career","employment","recruitment","product","ui","mobile","forms"},
 "career":{"job","recruitment","product","ui","mobile"},
 "recruitment":{"job","career","product","ui","forms"},
 "mobile":{"product","ui","onboarding","navigation"},
 "saas":{"product","ui","landing","dashboard","onboarding"},
 "landing":{"marketing","conversion","hero"},
 "dashboard":{"product","ui","web","data"},
 "website":{"web","landing","gallery"}
}

def tokenize(value):
    result=set(TOKENS.findall(value.lower()))
    for token in list(result): result.update(EXPAND.get(token,set()))
    return result

def load(path=CATALOG):
    data=json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(data,dict) or not isinstance(data.get("sources"),list):
        raise ValueError("catalogue must contain a sources array")
    return data

def select(sources, query, limit=5):
    q=tokenize(query); ranked=[]
    for index,s in enumerate(sources):
        identity=tokenize(f"{s.get('id','')} {s.get('name','')}")
        categories=tokenize(" ".join(s.get("categories",[])))
        strengths=tokenize(" ".join(s.get("strengths",[])))
        score=6*len(q&identity)+4*len(q&categories)+2*len(q&strengths)
        ranked.append((score,index,s))
    ranked.sort(key=lambda x:(-x[0],x[1]))
    positive=[x for x in ranked if x[0]>0]
    candidates=positive or ranked; output=[]; hosts=set()
    for score,_,source in candidates:
        host=urlparse(source["url"]).netloc.lower()
        if host in hosts: continue
        output.append({**source,"score":score}); hosts.add(host)
        if len(output)>=limit: break
    return output

def markdown(query, results):
    lines=["# Suggested inspiration sources","",f"Query: `{query}`","","Candidates only—open pages and record actual evidence.","","| Source | URL | Useful for | Cautions |","|---|---|---|---|"]
    for s in results:
        lines.append(f"| {s['name']} | {s['url']} | {'; '.join(s['strengths'])} | {'; '.join(s['cautions'])} |")
    return "\n".join(lines)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("query"); p.add_argument("--max-results","-n",type=int,default=5,choices=range(1,11),metavar="1-10")
    p.add_argument("--format",choices=("markdown","json"),default="markdown"); p.add_argument("--catalog",type=Path,default=CATALOG)
    a=p.parse_args()
    try: results=select(load(a.catalog)["sources"],a.query,a.max_results)
    except Exception as error: print(f"ERROR: {error}",file=sys.stderr); return 1
    print(json.dumps({"query":a.query,"results":results},indent=2) if a.format=="json" else markdown(a.query,results)); return 0
if __name__=="__main__": raise SystemExit(main())
