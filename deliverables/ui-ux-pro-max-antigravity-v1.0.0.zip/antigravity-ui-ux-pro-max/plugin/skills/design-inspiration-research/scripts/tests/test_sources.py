import importlib.util,json,tempfile,unittest
from pathlib import Path
SCRIPTS=Path(__file__).resolve().parent.parent
def module(name,file):
 spec=importlib.util.spec_from_file_location(name,SCRIPTS/file); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
selector=module("selector","select_sources.py"); validator=module("validator","validate_sources.py")
class Tests(unittest.TestCase):
 def test_catalog(self): self.assertEqual(validator.validate(),[])
 def test_bound(self): self.assertEqual(len(selector.select(selector.load()["sources"],"mobile job search",3)),3)
 def test_product_sources(self):
  ids={x["id"] for x in selector.select(selector.load()["sources"],"mobile job onboarding product ui",5)}
  self.assertTrue(ids & {"mobbin","pageflows","refero","saasframe"})
 def test_placeholder_rejected(self):
  data={"schemaVersion":1,"sources":[{"id":"bad","name":"Bad","url":"https://example.com/[site]","categories":["x"],"strengths":["x"],"cautions":["x"]}]}
  with tempfile.TemporaryDirectory() as folder:
   p=Path(folder)/"sources.json"; p.write_text(json.dumps(data)); errors=validator.validate(p)
  self.assertTrue(any("placeholder" in e for e in errors))
if __name__=="__main__": unittest.main()
