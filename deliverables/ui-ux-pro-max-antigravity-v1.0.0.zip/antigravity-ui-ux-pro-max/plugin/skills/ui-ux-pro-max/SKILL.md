---
name: ui-ux-pro-max
description: Designs, improves, implements, and audits web or mobile product interfaces using searchable UI/UX guidance. Use for pages, components, design systems, responsive layouts, accessibility, interaction, motion, typography, color, and visual performance. Supports FAST, FULL, and AUDIT modes, preserves existing stacks, and verifies code changes.
---

# UI/UX Pro Max — Lean Antigravity Edition

This is the single entry point for product UI work. Do not simulate a multi-agent agency, emit phase-by-phase JSON, or load every reference.

## Choose exactly one mode

- **FAST** — scoped fix, component, page, or improvement in an existing project. No web research unless requested.
- **FULL** — new product, design system, or major redesign. Research is optional and bounded.
- **AUDIT** — review and recommendations only. Do not edit code until approved.

Honor an explicit mode. Existing-project work defaults to FAST. Words such as “beautiful” or “premium” do not justify FULL mode.

## Non-negotiable rules

1. Preserve behaviour: visual work must not silently alter APIs, auth, routing, databases, business logic, or content meaning.
2. Preserve the detected framework and styling system. Ask before adding/replacing component or animation libraries.
3. Check Git status and respect unrelated user work.
4. Establish a baseline with the project's existing build, type, lint, or test command when feasible. Separate pre-existing failures.
5. Make the smallest coherent diff. One component is not permission to redesign the app.
6. Fail closed: fix/revert newly introduced failures before expanding scope.
7. Never claim a browser check, score, test, or command ran unless it actually did.
8. Never fabricate testimonials, partners, certifications, statistics, or other trust claims.
9. Inspiration informs principles; never copy source code, assets, branding, text, or an exact layout.
10. Ask before new dependencies, destructive commands, broad rewrites, migrations, or production actions.

## Search the local design database

On the global Windows installation, use PowerShell:

```powershell
$SkillRoot = Join-Path $env:USERPROFILE ".gemini\config\plugins\ui-ux-pro-max\skills\ui-ux-pro-max"
py -3 (Join-Path $SkillRoot "scripts\search.py") "<query>" --domain <domain> --max-results 3
```

If `py -3` is unavailable, try `python`, then `python3`. Never install Python silently.

Domains include `product`, `style`, `color`, `typography`, `landing`, `ux`, `icons`, `gsap`, `react`, `web`, `chart`, and `google-fonts`.

Stack guidance:

```powershell
py -3 (Join-Path $SkillRoot "scripts\search.py") "<focused query>" --stack react --max-results 3
```

FULL-mode design system:

```powershell
py -3 (Join-Path $SkillRoot "scripts\search.py") "<product industry audience qualities>" --design-system --variance 4 --motion 3 --density 5 -p "<Project Name>" --persist --output-dir "<project root>"
```

Query only needed domains, use at most three results, detect the real stack, and treat results as recommendations. Read `references/quick-reference.md` or `references/pro-rules.md` only on demand.

## FAST workflow

1. Identify the exact target, desired outcome, and behaviour that must remain unchanged. Ask only blocking questions.
2. Read the target and direct dependencies, design tokens, shared components, data states, responsive conventions, Git status, and package scripts.
3. Run the smallest relevant baseline check. Record existing failures.
4. Reuse an existing persisted design system or run one/two focused searches. Give a plan of at most five bullets.
5. Implement minimally using current tokens/primitives. Cover relevant loading, empty, error, disabled, focus, hover, and active states.
6. Re-run checks. If browser tooling is available, inspect relevant breakpoints and console. Report exactly what was and was not verified.

## FULL workflow

1. Inspect the repository before asking questions.
2. Ask at most five grouped missing questions: audience, primary task, brand constraints, content readiness, and device priority.
3. Save a concise brief in the project instead of a long chat report.
4. Apply `design-inspiration-research` only when external inspiration is requested; otherwise skip browsing.
5. Generate one persisted master design system with restrained defaults unless requirements differ.
6. Define semantic colors, type, spacing, radii, elevation, widths, interaction states, and motion rules before pages.
7. Plan and implement in small batches, verifying after each. Never generate the whole app before the first build/browser check.
8. Pass the completion gate before declaring success.

## AUDIT workflow

1. Define scope and target devices.
2. Inspect code and, when available, the running UI.
3. Rank evidence-backed findings: Critical, High, Medium, Low.
4. Cite file/line, component, route, actual browser observation, or command output.
5. Recommend the smallest ordered fixes. Do not edit until approved.

## Quality requirements

- Normal text contrast ≥ 4.5:1; large text/UI graphics ≥ 3:1.
- Keyboard access, visible focus, semantics, labels, meaningful alt text, and no color-only meaning.
- Touch targets target 44×44 CSS px.
- No unintended horizontal scrolling; check approximately 375, 768, 1024, and 1440 px when applicable.
- Handle long content, empty/error/loading states, safe areas, and mobile keyboard constraints.
- Motion must communicate state/hierarchy/feedback. Prefer transform/opacity, usually 150–300 ms, and respect `prefers-reduced-motion`.
- Avoid continuous marquees, large animated blurs, and decorative mobile parallax. Do not add motion libraries merely because the database mentions one.
- Measure rather than invent targets: LCP ≤ 2.5 s, INP ≤ 200 ms, CLS ≤ 0.1.
- Use responsive, dimensioned images; lazy-load below-fold media.

## Completion gate

Complete only when requested behaviour works, unrelated behaviour is intact, no new check failures exist, relevant states and responsiveness are handled, browser checks ran when available, and the response concisely lists files changed, actual checks/results, and remaining risks.

## Context efficiency

Do not output duplicate Markdown and JSON, load every skill/reference, rerun discovery for existing work, or browse in FAST mode unless asked. Persist durable project decisions and keep progress updates short.
