# Attribution

This Antigravity-native package contains a modified distribution of UI/UX Pro Max data and search tools from https://github.com/nextlevelbuilder/ui-ux-pro-max-skill at commit `14ddef5c05e52d7c253b8f0129de7bcd1045ae5b` (`v2.12.0`). Upstream is MIT licensed; see `UPSTREAM-LICENSE.txt`.

The lean Antigravity workflows, inspiration catalogue, installer, doctor, and rollback tools are adaptations made for this package. They are not the unofficial former “Design Agency OS v4.1” installation. No API key, MCP server, paid service, external Python package, or Claude installation is required.
