﻿[CmdletBinding()]
param([string]$TargetRoot = (Join-Path $env:USERPROFILE ".gemini\config\plugins"), [switch]$SkipDoctor)
$ErrorActionPreference="Stop"
$Root=Split-Path -Parent $MyInvocation.MyCommand.Path
$Source=Join-Path $Root "plugin"
$ManifestPath=Join-Path $Source "plugin.json"
function Step($m){ Write-Host "`n==> $m" -ForegroundColor Cyan }
if(-not(Test-Path $ManifestPath)){ throw "Incomplete package: plugin\plugin.json missing. Extract the full ZIP." }
$Manifest=Get-Content $ManifestPath -Raw|ConvertFrom-Json
if($Manifest.name -ne "ui-ux-pro-max"){ throw "Unexpected plugin name." }
$Required=@("skills\ui-ux-pro-max\SKILL.md","skills\ui-ux-pro-max\scripts\search.py","skills\design-inspiration-research\SKILL.md","skills\design-inspiration-research\resources\sources.json")
foreach($r in $Required){ if(-not(Test-Path(Join-Path $Source $r))){ throw "Missing plugin\$r" } }
$Forbidden=@(Get-ChildItem $Source -Recurse -Force|Where-Object{$_.Name -in @(".env",".coverage","__pycache__") -or $_.Extension -eq ".pyc"})
if($Forbidden.Count){ throw "Secret/runtime files found: $($Forbidden.FullName -join ', ')" }
$Target=Join-Path $TargetRoot "ui-ux-pro-max"
$BackupRoot=Join-Path $env:USERPROFILE ".gemini\config\plugin-backups\ui-ux-pro-max"
$Backup=$null; $Started=$false; $OldEnv=$false
if(Get-Process -ErrorAction SilentlyContinue|Where-Object{$_.ProcessName -match "antigravity"}){ Write-Warning "Antigravity is running. Restart it after installation." }
try{
 New-Item -ItemType Directory $TargetRoot -Force|Out-Null
 if(Test-Path $Target){
  Step "Backing up current plugin"
  New-Item -ItemType Directory $BackupRoot -Force|Out-Null
  $Backup=Join-Path $BackupRoot (Get-Date -Format "yyyyMMdd-HHmmss")
  $OldEnv=[bool](Get-ChildItem $Target -Filter ".env" -Recurse -Force -ErrorAction SilentlyContinue)
  Copy-Item -LiteralPath $Target -Destination $Backup -Recurse -Force
  Write-Host "Backup: $Backup"
 }
 Step "Installing lean plugin"
 $Started=$true
 if(Test-Path $Target){ Remove-Item $Target -Recurse -Force }
 Copy-Item -LiteralPath $Source -Destination $Target -Recurse -Force
 if(-not(Test-Path(Join-Path $Target "plugin.json"))){ throw "Copy verification failed." }
 if($OldEnv){ Write-Warning "Old plugin contained .env. Rotate any real key; it exists only in backup." }
 if(-not $SkipDoctor){ Step "Running health checks"; & (Join-Path $Root "Doctor.ps1") -PluginPath $Target; if($LASTEXITCODE -ne 0){ throw "Health checks failed." } }
 Write-Host "`nInstallation complete." -ForegroundColor Green
 Write-Host "Restart Antigravity, start a NEW conversation, and confirm this plugin exposes exactly 2 skills."
 if($Backup){ Write-Host "Rollback backup: $Backup" }
}catch{
 Write-Host "`nInstallation failed: $($_.Exception.Message)" -ForegroundColor Red
 if($Started -and (Test-Path $Target)){ Remove-Item $Target -Recurse -Force -ErrorAction SilentlyContinue }
 if($Backup -and (Test-Path $Backup)){ Copy-Item -LiteralPath $Backup -Destination $Target -Recurse -Force; Write-Host "Previous plugin restored." -ForegroundColor Yellow }
 exit 1
}
